package com.bage.domain;

/**
 * 通过XML配置的Bean
 * @author bage
 *
 */
public class XMLBean {

}

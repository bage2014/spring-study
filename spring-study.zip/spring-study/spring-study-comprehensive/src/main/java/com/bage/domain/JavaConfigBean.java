package com.bage.domain;

/**
 * 通过JavaConfig实现的Bean
 * @author bage
 *
 */
public class JavaConfigBean {

}

package com.bage.domain;

import org.springframework.stereotype.Component;

/**
 * 自动注入的Bean
 * @author bage
 *
 */
@Component
public class AutowiredBean {

}

package com.bage.domain;

/**
 * 通过引入XML配置的Bean
 * @author bage
 *
 */
public class XMLBeanForImport {

}

package com.bage.service;

public interface HelloService {

	String sayHello(String text);

}
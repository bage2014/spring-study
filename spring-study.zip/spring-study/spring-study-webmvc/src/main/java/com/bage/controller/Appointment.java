package com.bage.controller;

public class Appointment {

}

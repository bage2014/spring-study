package com.bage.controller;

import java.util.Map;

public class Clinic {

	public Map<? extends String, ? extends Object> getVets() {
		// TODO Auto-generated method stub
		return null;
	}

}

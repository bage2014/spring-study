package com.bage.controller;

public class AppointmentForm {

}

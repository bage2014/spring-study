package com.bage.controller;

import java.util.Date;
import java.util.Map;

public class AppointmentBook {

	public Map<String, Appointment> getAppointmentsForToday() {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Appointment> getAppointmentsForDay(Date day) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addAppointment(AppointmentForm appointment) {
		// TODO Auto-generated method stub
		
	}

}

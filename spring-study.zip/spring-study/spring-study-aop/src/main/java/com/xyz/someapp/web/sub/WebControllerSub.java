package com.xyz.someapp.web.sub;

import org.springframework.stereotype.Controller;

@Controller
public class WebControllerSub {

	public void methodSub1(){
		System.out.println("com.xyz.someapp.web.sub.WebControllerSub.methodSub1() is work" );
	}
	public void methodSub2(){
		System.out.println("com.xyz.someapp.web.sub.WebControllerSub.methodSub2() is work" );
	}
}

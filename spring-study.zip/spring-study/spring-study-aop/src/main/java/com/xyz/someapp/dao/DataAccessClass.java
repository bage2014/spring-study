package com.xyz.someapp.dao;

import org.springframework.stereotype.Repository;

@Repository
public class DataAccessClass {

	public void method(){
		System.out.println("com.xyz.someapp.dao.DataAccessClass.method() is work" );
	}
	
}

package com.xyz.myapp;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration("myappAppConfig")
@ComponentScan
public class AppConfig {

}

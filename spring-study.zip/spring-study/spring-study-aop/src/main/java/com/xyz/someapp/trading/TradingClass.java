package com.xyz.someapp.trading;

import org.springframework.stereotype.Component;

@Component
public class TradingClass {

	public void trading(){
		System.out.println("com.xyz.someapp.trading.TradingClass.trading() is work");
	}
}

package com.xyz.someapp.web;

import org.springframework.stereotype.Controller;

@Controller
public class WebController1 {

	public void method11(){
		System.out.println("com.xyz.someapp.web.WebController1.method11() is work" );
	}
	public void method12(){
		System.out.println("com.xyz.someapp.web.WebController1.method12() is work" );
	}
}

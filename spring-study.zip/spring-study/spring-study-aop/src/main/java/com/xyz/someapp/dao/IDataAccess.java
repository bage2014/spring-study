package com.xyz.someapp.dao;

public interface IDataAccess {

	void method();

}
package com.xyz.someapp.service;

public interface IServiceBean {

	void method();

}
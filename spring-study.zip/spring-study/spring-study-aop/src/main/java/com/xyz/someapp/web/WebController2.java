package com.xyz.someapp.web;

import org.springframework.stereotype.Controller;

@Controller
public class WebController2 {

	public void method21(){
		System.out.println("com.xyz.someapp.web.WebController1.method21() is work" );
	}
	public void method22(){
		System.out.println("com.xyz.someapp.web.WebController1.method22() is work" );
	}
}

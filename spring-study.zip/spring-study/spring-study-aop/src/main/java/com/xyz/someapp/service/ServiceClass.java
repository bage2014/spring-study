package com.xyz.someapp.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceClass {
	
	public void method(){
		System.out.println("com.xyz.someapp.service.ServiceClass.method() is work" );
	}
	
}

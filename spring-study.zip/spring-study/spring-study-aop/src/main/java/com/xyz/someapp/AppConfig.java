package com.xyz.someapp;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration("someappAppConfig")
@ComponentScan
public class AppConfig {

}

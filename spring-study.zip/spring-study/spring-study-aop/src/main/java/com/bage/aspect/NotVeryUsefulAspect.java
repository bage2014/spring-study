package com.bage.aspect;

// 如果xml没有配置，可以使用@Aspect注解
// /spring-study-aop/src/main/java/com/bage/template.xml
public class NotVeryUsefulAspect {

}

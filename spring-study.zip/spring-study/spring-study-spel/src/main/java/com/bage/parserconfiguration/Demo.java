package com.bage.parserconfiguration;

import java.util.List;

public class Demo {
    public List<String> list;
}

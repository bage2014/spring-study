package com.bage;

public class PlaceOfBirth {

	String City;
	
	public PlaceOfBirth(String City) {
		this.City = City;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

}

package com.bage.xml;

public class ShapeGuess {

	private int initialShapeSeed ;

	public int getInitialShapeSeed() {
		return initialShapeSeed;
	}

	public void setInitialShapeSeed(int initialShapeSeed) {
		this.initialShapeSeed = initialShapeSeed;
	}

	@Override
	public String toString() {
		return "ShapeGuess [initialShapeSeed=" + initialShapeSeed + "]";
	}
	
}

package com.bage.evaluationcontext;

import java.util.ArrayList;
import java.util.List;

public class Simple {
    public List<Boolean> booleanList = new ArrayList<Boolean>();
}

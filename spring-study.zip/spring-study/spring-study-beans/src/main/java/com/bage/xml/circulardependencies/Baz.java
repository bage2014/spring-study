package com.bage.xml.circulardependencies;

public class Baz {

	private Bar bar;
	
	public Bar getBar() {
		return bar;
	}
	public void setBar(Bar bar) {
		this.bar = bar;
	}

}

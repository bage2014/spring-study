package com.bage.annotation.autowired;

import org.springframework.stereotype.Service;

//@Component
@Service("autowiredCustomerPreferenceDao")
public class CustomerPreferenceDao {

}

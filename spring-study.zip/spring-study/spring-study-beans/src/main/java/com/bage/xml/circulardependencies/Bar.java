package com.bage.xml.circulardependencies;

public class Bar {

	private Baz baz;

	public Baz getBaz() {
		return baz;
	}

	public void setBaz(Baz baz) {
		this.baz = baz;
	}

	
}

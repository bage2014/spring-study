package com.bage.xml.base;

public class Hello {

	public void method() {
		System.out.println("HelloBean.method is work ");
	}
	
}

package com.bage.xml.lazyinit;

public class BaseBean {

}

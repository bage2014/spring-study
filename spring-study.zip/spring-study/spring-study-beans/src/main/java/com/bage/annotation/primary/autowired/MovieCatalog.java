package com.bage.annotation.primary.autowired;

public class MovieCatalog {

}

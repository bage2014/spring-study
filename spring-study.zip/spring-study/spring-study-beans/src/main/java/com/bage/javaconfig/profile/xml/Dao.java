package com.bage.javaconfig.profile.xml;

public interface Dao {

	void todo();

}
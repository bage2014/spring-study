package com.bage.xml.Innerclass;

public class OuterClass {

	
	
	public static class InnerClass{
		public void test(){
			System.out.println("InnerClass.test() is work ");
		}
	}
	
}

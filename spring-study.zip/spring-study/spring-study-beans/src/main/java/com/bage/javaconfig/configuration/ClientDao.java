package com.bage.javaconfig.configuration;

public interface ClientDao {

}
package com.bage.javaconfig.Composing;

public interface TransferService {

}
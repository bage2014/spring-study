package com.bage.xml.dependson;

public class BaseBean2 {

}

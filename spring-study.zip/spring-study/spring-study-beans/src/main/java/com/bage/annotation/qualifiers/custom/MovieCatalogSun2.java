package com.bage.annotation.qualifiers.custom;

import com.bage.annotation.qualifiers.MovieCatalog;

public class MovieCatalogSun2 extends MovieCatalog{

}

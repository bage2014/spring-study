package com.bage.javaconfig.basic;

public class MyService {

	 public void init() {
         // initialization logic
	 }
	 
     public void cleanup() {
         // destruction logic
     }
	
	public void doStuff() {
		System.out.println("doStuff() is work ");
	}

}

package com.bage.annotation.standardannotations;

import javax.inject.Named;

@Named // Instead of @Component, @javax.inject.Named or javax.annotation.ManagedBean may be used as follows:
// @Named("standardannotationsMovieFinder")
// @ManagedBean("standardannotationsMovieFinder") could be used as well
public class StandardannotationsMovieFinder {

}

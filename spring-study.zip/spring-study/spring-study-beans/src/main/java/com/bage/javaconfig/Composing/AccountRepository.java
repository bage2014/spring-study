package com.bage.javaconfig.Composing;

public class AccountRepository {

}

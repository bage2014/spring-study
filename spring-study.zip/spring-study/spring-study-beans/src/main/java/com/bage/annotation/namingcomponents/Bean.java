package com.bage.annotation.namingcomponents;

import org.springframework.stereotype.Component;

@Component // 默认名字：bean
// 起名字 == @Component("namedBean") || @Component(value = "namedBean") 
public class Bean {

}

package com.bage.annotation.resource;

import org.springframework.stereotype.Component;

@Component(value="myMovieFinder")
public class MovieFinder {

}

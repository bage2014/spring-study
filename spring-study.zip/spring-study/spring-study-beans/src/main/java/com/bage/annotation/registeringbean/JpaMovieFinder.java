package com.bage.annotation.registeringbean;

import org.springframework.stereotype.Repository;

@Repository
public class JpaMovieFinder implements MovieFinder {
        // implementation elided for clarity
}
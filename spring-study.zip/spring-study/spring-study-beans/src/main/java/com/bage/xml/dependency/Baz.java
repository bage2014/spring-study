package com.bage.xml.dependency;

public class Baz {

}

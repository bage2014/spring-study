package com.bage.annotation.generics;

public class Store<E>{

}

package com.bage.annotation.resource;

import org.springframework.stereotype.Component;

@Component(value="resourceCustomerPreferenceDao")
public class CustomerPreferenceDao {

}

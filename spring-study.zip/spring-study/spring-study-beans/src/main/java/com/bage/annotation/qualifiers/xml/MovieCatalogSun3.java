package com.bage.annotation.qualifiers.xml;

import com.bage.annotation.qualifiers.MovieCatalog;

public class MovieCatalogSun3 extends MovieCatalog {

}

package com.bage.xml.scopes.prototype;

public class DefaultAccountService {

}

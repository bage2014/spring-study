package com.bage.xml.shortcut;

public class Foo {

}

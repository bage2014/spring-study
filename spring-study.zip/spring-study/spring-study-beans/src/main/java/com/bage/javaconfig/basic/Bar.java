package com.bage.javaconfig.basic;

public class Bar {

}

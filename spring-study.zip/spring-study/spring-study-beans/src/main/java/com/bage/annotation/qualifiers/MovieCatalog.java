package com.bage.annotation.qualifiers;

public class MovieCatalog {

}

package com.bage.annotation.primary.xml;

public class MovieCatalog {

}

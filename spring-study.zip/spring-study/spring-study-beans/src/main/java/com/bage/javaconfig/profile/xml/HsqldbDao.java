package com.bage.javaconfig.profile.xml;

public class HsqldbDao implements Dao {

	/* (non-Javadoc)
	 * @see com.bage.javaconfig.profile.Dao#todo()
	 */
	public void todo(){
		System.out.println("HsqldbDao.todo() is work");
	}
	
}

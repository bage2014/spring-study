package com.bage.javaconfig.profile.xml;

public class OracleDao implements Dao {

	/* (non-Javadoc)
	 * @see com.bage.javaconfig.profile.Dao#todo()
	 */
	public void todo(){
		System.out.println("OracleDao.todo() is work");
	}
	
}

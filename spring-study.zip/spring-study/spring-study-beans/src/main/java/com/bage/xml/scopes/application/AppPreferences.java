package com.bage.xml.scopes.application;

public class AppPreferences {

}

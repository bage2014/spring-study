package com.bage.annotation.qualifiers.custom;

import org.springframework.stereotype.Component;

@Component(value="customActionMovie")
public class ActionMovie {

}

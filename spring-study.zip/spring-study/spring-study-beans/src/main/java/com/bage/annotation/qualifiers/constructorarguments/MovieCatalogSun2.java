package com.bage.annotation.qualifiers.constructorarguments;

import org.springframework.stereotype.Component;

import com.bage.annotation.qualifiers.MovieCatalog;

@Component(value="movieCatalogSun2")
public class MovieCatalogSun2 extends MovieCatalog{

}

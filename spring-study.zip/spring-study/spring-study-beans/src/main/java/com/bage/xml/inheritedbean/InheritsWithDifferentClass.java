package com.bage.xml.inheritedbean;

public class InheritsWithDifferentClass extends InheritedTestBean{

}

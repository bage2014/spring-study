package com.bage.javaconfig.loadtimeweaver;

import org.springframework.context.annotation.Configuration;

@Configuration
//@EnableLoadTimeWeaving
public class LoadTimeWeaverAppConfig {
	// <beans><context:load-time-weaver/></beans>
	
}

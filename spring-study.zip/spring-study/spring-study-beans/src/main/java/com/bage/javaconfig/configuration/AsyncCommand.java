package com.bage.javaconfig.configuration;

public class AsyncCommand extends Command{

}

package com.bage.xml.autowiringcollaborators;

public class CPU {
	
}

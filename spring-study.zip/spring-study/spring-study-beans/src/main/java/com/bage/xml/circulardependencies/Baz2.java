package com.bage.xml.circulardependencies;

public class Baz2 {

	public Baz2 (Bar bar){
		
	}

}

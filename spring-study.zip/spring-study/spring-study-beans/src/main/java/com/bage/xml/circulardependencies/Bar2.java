package com.bage.xml.circulardependencies;

public class Bar2 {

	public Bar2 (Baz baz){
		
	}
	
}

package com.bage.annotation.primary.javaconfig;

public class MovieCatalogSecond extends MovieCatalog {

	
	
}

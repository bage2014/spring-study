package com.bage.javaconfig.profile.xml;

public class MySQLDao implements Dao {

	/* (non-Javadoc)
	 * @see com.bage.javaconfig.profile.Dao#todo()
	 */
	public void todo(){
		System.out.println("MySQLDao.todo() is work");
	}
	
}

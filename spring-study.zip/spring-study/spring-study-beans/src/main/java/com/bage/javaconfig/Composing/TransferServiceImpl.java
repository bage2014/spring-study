package com.bage.javaconfig.Composing;

public class TransferServiceImpl implements TransferService {

	public TransferServiceImpl(AccountRepository accountRepository) {
		// TODO Auto-generated constructor stub
	}

}

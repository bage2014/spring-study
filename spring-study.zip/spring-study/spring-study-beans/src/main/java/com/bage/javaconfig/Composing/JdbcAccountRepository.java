package com.bage.javaconfig.Composing;

import javax.sql.DataSource;

public class JdbcAccountRepository extends AccountRepository{

	public JdbcAccountRepository(DataSource dataSource) {
		// TODO Auto-generated constructor stub
	}

}

package com.bage.javaconfig.Composing;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigA {

}

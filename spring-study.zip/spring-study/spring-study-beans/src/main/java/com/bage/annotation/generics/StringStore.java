package com.bage.annotation.generics;

public class StringStore extends Store<String>{

}

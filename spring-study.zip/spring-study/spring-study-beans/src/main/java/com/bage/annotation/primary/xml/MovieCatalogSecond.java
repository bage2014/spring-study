package com.bage.annotation.primary.xml;

public class MovieCatalogSecond extends MovieCatalog {

	
	
}

package com.bage.annotation;

public interface SayHello {

	String sayHello(String text);

}
package com.bage.javaconfig.profile.methodlevel;

public interface Dao {

	void todo();

}
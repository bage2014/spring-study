package com.bage.javaconfig.basic;

public class MyServiceImpl extends MyService {

}

package com.bage.annotation.autowired.required;

public class MovieFinder {

}

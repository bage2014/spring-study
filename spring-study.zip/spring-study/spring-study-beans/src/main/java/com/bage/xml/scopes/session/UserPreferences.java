package com.bage.xml.scopes.session;

public class UserPreferences {

}

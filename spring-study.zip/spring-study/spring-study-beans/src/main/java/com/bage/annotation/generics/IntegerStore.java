package com.bage.annotation.generics;

public class IntegerStore extends Store<Integer>{

}

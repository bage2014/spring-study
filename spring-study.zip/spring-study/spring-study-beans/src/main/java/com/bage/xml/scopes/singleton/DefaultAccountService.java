package com.bage.xml.scopes.singleton;

public class DefaultAccountService {

}

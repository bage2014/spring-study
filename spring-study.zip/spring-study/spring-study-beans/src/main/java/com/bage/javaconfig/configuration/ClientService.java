package com.bage.javaconfig.configuration;

public interface ClientService {

	void setClientDao(ClientDao clientDao);

}
package com.bage.annotation.primary.autowired;

import org.springframework.stereotype.Component;

@Component
//@Primary
public class MovieCatalogFirst extends MovieCatalog {

}

package com.bage.xml.startupshutdowncallbacks;

public class LifecycleProcessor{

}

package com.bage.annotation.qualifiers.customautowireconfigurer;

public @interface CustomQualifier {

}

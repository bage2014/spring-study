package com.bage.annotation.qualifiers.custom;

public enum Format {
    VHS, DVD, BLURAY
}

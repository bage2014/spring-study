package com.bage.javaconfig.configuration;

public class ClientDaoImpl implements ClientDao {

}

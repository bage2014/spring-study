package com.bage.xml.dependson;

public class ManagerBean {

	private BaseBean baseBean;
	
	public BaseBean getBaseBean() {
		return baseBean;
	}

	public void setBaseBean(BaseBean baseBean) {
		this.baseBean = baseBean;
	}
	
}

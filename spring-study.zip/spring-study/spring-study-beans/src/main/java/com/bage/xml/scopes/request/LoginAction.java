package com.bage.xml.scopes.request;

public class LoginAction {

}

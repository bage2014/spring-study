package com.bage.annotation.qualifiers.plaindescriptive;

import org.springframework.stereotype.Component;

import com.bage.annotation.qualifiers.MovieCatalog;

@Component(value="movieCatalogSun1")
public class MovieCatalogSun1 extends MovieCatalog{

}

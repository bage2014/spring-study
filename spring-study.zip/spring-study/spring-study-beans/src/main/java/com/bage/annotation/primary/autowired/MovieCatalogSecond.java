package com.bage.annotation.primary.autowired;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class MovieCatalogSecond extends MovieCatalog {

}

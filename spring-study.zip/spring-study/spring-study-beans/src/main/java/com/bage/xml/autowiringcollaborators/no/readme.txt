
默认的方式，一般都是这种方式进行配置

例如：com.bage.xml.dependency 下的实现方式


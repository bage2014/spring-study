package com.bage.annotation.autowired;

import org.springframework.stereotype.Component;

@Component
public class MovieCatalog {

}

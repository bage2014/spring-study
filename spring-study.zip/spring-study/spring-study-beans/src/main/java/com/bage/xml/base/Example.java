package com.bage.xml.base;

public class Example {

	public void method() {
		System.out.println("HelloBean.method is work ");
	}
	
}

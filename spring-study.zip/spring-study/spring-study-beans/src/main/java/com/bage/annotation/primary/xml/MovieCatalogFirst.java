package com.bage.annotation.primary.xml;

public class MovieCatalogFirst extends MovieCatalog {

	
	
}

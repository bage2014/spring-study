package com.bage.xml.value;

public class RefBean {

	
	
}

package com.bage.annotation.qualifiers.custom;

import com.bage.annotation.qualifiers.MovieCatalog;

public class MovieCatalogSun1 extends MovieCatalog{

}

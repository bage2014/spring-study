package com.bage;

public class Template {

	public void method() {
		System.out.println("HelloBean.method is work ");
	}
	
}

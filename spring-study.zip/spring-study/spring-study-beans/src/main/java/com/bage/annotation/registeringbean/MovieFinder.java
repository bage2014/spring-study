package com.bage.annotation.registeringbean;

public interface MovieFinder {

}
